from bits.main import run
